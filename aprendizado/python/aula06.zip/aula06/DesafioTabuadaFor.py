num = int(input("Digite um número: "))
for tab in range(1,11):
    print('{0} x {1} = {2}'.format(num,tab,(num*tab)))
    # print(f"{tab} x {num} = {(tab+1)*num}")