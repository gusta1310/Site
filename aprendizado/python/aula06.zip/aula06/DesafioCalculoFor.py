
num = 0

for i in range(10):
    num += int(input(f"Digite o {i+1}º numero: " ))
print(f"A soma dos valores é: {num}")