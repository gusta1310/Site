animais = ['gato', 'cahorro', 'leão', 'camelo']

for animal in animais:
    print("A palavra", animal, "tem um tamanho: ", len(animal))
    # print(animal)

print("----------------------------------------------------------")

sequencia = [0, 1, 2, 3, 4, 5]

for seq in sequencia:
    print(seq)

print("----------------------------------------------------------")

nome = "aline"

for letra in nome:
    print(letra)

print("----------------------------------------------------------")

for i in range(10):
    print(i+1)

print("----------------------------------------------------------")

for i in range(3, 8):
    print(i)

print("----------------------------------------------------------")

for i in range(0,21,2):
    print(i, end=" ")

print("----------------------------------------------------------")

for i in range(30, 101, 3):
    print(i, end=" ")